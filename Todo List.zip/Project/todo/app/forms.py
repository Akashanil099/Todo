from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.forms import ModelForm, Textarea
from . import models
from django.forms import DateInput
from django.forms.fields import DateField

# Create your forms here.

class NewUserForm(UserCreationForm):
	email = forms.EmailField(required=True)

	class Meta:
		model = User
		fields = ("username", "email", "password1", "password2")

	def save(self, commit=True):
		user = super(NewUserForm, self).save(commit=False)
		user.email = self.cleaned_data['email']
		if commit:
			user.save()
		return user
	

class DateInput(DateInput):
    input_type = 'date'
	

class TaskForm(forms.Form):
    title = forms.CharField(label="Task", max_length=100)
    description = forms.CharField(widget=forms.Textarea)
    due_date = DateField(widget=DateInput)
    
    def save(self, commit=True):
        task = models.Task()
        task.title = self.cleaned_data["title"]
        task.description = self.cleaned_data["description"]
        task.due_date = self.cleaned_data["due_date"]
        task.completed = False
        task.save()