from django.db import models
from django.forms import ModelForm


class Task(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    due_date = models.DateField(blank=True, null=True)
    completed = models.BooleanField()


    def __str__(self):
        return self.title
    