from django.urls import path
from django.views.generic.base import TemplateView 

from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path("register", views.register_request, name="register"),
    path("task", views.task_creation, name="task"),
    path("task/complete/<int:task_id>", views.mark_completed, name="mark_complete"),
    path("task/incomplete/<int:task_id>", views.mark_incompleted, name="mark_incomplete"),
]