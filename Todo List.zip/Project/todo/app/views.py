from django.shortcuts import render,redirect
from django.http import HttpResponse
from .forms import NewUserForm, TaskForm
from django.contrib.auth import login
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Task
from datetime import date


def register_request(request):
	if request.method == "POST":
		form = NewUserForm(request.POST)
		if form.is_valid():
			user = form.save()
			login(request, user)
			print(user)
			messages.success(request, "Registration successful." )
			return redirect("home")
		messages.error(request, "Unsuccessful registration. Invalid information.")
	form = NewUserForm()
	return render (request=request, template_name="registration/registration.html", context={"register_form":form})

@login_required(login_url='/accounts/login/')
def task_creation(request):
	if request.method == "POST":
		form = TaskForm(request.POST)
		if form.is_valid():
			form.save()
			messages.success(request, "Task creation successful." )
			return redirect("home")
		messages.error(request, "Unsuccessful task creation. Invalid information.")
	form = TaskForm()
	return render (request=request, template_name="task.html", context={"form":form})

@login_required(login_url='/accounts/login/')
def home(request):
	status = request.GET.get("status")
	completed_status = False
	if status == "completed":
		completed_status = True
	tasks = Task.objects.filter(completed=completed_status).values("title", "description", "due_date", "completed", "id")

	for task in tasks:
		if date.today() > task["due_date"] and not completed_status:
			task["expired"] = True
	return render(request=request, template_name="home.html",context= {"tasks":tasks})


@login_required(login_url='/accounts/login/')
def mark_completed(request, task_id):
	task = Task.objects.get(id=task_id)
	task.completed = True
	task.save()
	return redirect("home")


@login_required(login_url='/accounts/login/')
def mark_incompleted(request, task_id):
	task = Task.objects.get(id=task_id)
	task.completed = False
	task.save()
	return redirect("home")
